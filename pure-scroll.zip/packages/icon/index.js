import loading from './loading.vue';

export default loading;
