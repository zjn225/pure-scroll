<template>
  <div class="scroll-wrap">
     this is pure-scroll h2334445555
  </div>
</template>

<script>

export default {
  name: 'scroll',

  components: {},

  props: {
    list: {
      type: Array
    }
  },

  data() {
    return {

    };
  },

  mounted() {

  },

  computed: {

  },

  methods: {
  }
};
</script>
