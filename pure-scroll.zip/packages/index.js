import pureScroll from './pure-scroll/index';
import './pure-scroll/index.scss';
import './icon/loading.scss';
import locale from './locale/index';

export default {
  install (Vue, options = {}) {
    Vue.component('pure-scroll', pureScroll);

    locale.use(options.lang);
  }
};

export {
  locale
};
