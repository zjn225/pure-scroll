export default {
  refresh: {
    pulling: '下拉刷新',
    loosing: '释放刷新',
    refresh: '正在刷新',
    success: '刷新完成'
  },
  pureScroll: {
    loading: '正在加载',
    finished: '没有更多了',
    error: '请求失败，点击重新加载'
  }
};
