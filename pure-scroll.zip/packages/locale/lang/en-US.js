export default {
  refresh: {
    pulling: 'Pull down to refresh',
    loosing: 'Loosing to refresh',
    refresh: 'Refreshing',
    success: 'Refresh success'
  },
  pureScroll: {
    loading: 'Loading',
    finished: 'No more data',
    error: 'Request failed, click to reload'
  }
};
